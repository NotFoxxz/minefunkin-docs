# Event Showcase

A complete MineFunkin song (126 s, 140 BPM, A minor) whose effects are all `.event` scripts from its own
`events/` folder - 31 of them - plus 2 shaders in `shaders/`. Every big feature of the event scripts gets
its own moment, and a numbered caption top left names it right at that moment.

**Play it with the Microphone** (a fight against the dummy, or a player): the camera and the fighters
only exist in a fight. In practice (the Arcade Machine) everything else still runs - the lanes, the
texts, the pictures, the shaders.

Install: copy this folder into `.minecraft/MineFunkin/client/songs/`.

The event files are commented: start with `power_on.event`, then follow the numbers in their first
lines (that's the order the song shows them). The full language reference is `docs/event-scripts.md`
in the MineFunkin repository.

## What's in it

| Part | Bars | Events |
|---|---|---|
| Intro | 1-4 | Power On (the screen switches on like an old TV, with the title), Cam Sway |
| Verse 1 | 5-12 | Cam Follow, Judge Glow, Opponent Echo, Combo Meter (a song script - no chart event; its caption comes with the first "25 COMBO!") |
| Verse 2 | 13-20 | Spotlight, then Jiggle (the modchart's kick) |
| Build | 21-24 | Build Up (zoom, shake, 3-2-1), Kade Sway (wild on the opponent's bar: the lanes fly off), Spin |
| Drop | 25-32 | The Drop with a Shockwave and Jiggle, then Lane Lights, a second Shockwave, Hop |
| The dance | 33-40 | Dance Routine (both fighters, their own moves), Orbit Cam, Word by Word |
| Fake death | 41-44 | Fake Death, Drop Out - a heartbeat - Rise (a giant), Shockwave, the lanes come back |
| Breakdown | 45-48 | Scroller: the lanes across the whole screen, wrapping round |
| Rebuild | 49-52 | Switcheroo (the fighters swap places), Scroll Twist |
| Final drop | 53-68 | The Drop, Kick Hit, Logo Bump, Switcheroo back, Upside Down for four bars, Hop, a Switcheroo ping-pong |
| Outro | 69-72 | Halo, Finale (the live score), Power Off |

The wild moves (lanes off the screen, the playfield turning over) happen on bars where only the
opponent sings. Every effect keeps to its own property ("channel") or its own bars, so they stack
instead of fighting over a value: Jiggle = `strum[lane].wobbleX` / `.wobbleY`, Spin = `.angle`, Kade
Sway / Scroller / Hop / Drop Out / Halo = `.x` / `.y` (never at the same time), Spotlight = `.alpha`,
Judge Glow = `.scale`, Scroll Twist = `.scroll`, Opponent Echo = `strums.x` / `.y`, Cam Sway = `hud.x` /
`.y`, The Drop and Upside Down = `hud.angle` (never at the same time), Lane Lights = the strum
background, Cam Follow / Orbit Cam / Fake Death = the camera (one after the other), Kick Hit =
`fx.chromatic` + `fx.bloom`, Power On / Off = `shader[0]`, Shockwave = `shader[1]`.

## The music

Two simple synth leads play the melodies: a hollow square for you and a nasal 25 % pulse for the
opponent. They're the song's two vocal tracks, so a miss mutes your lead like a voice in FNF.

## Files

`Inst.ogg`, both `Voices-*.ogg`, `showcase-Normal.mfkn`, `showcase.mfknsong` and `logo.png` are written
by `tools/showcase/make_showcase.py`; the event files and the shaders are written by hand. Some of the
lane effects are rebuilt from a Taro / Kade style Lua modchart.
